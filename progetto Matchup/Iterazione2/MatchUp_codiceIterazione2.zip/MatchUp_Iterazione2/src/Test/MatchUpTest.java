package Test;
import Model.*;
import Eccezioni.*;


import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestMethodOrder;

import java.io.BufferedReader;
import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.LinkedList;
import java.util.Map;
 
import static org.junit.jupiter.api.Assertions.*;
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)

class MatchUpTest {
 
    MatchUp matchUp;
 
    @BeforeAll

    void setUp() {
 
        matchUp = MatchUp.getInstance();
 
        try(BufferedReader ftestoIn = new BufferedReader(new FileReader("strutture.txt"))){

            String[] info;

            while(ftestoIn.ready()){
 
                info = ftestoIn.readLine().split(",");

                Struttura s = new Struttura(info[0], info[1], info[2], info[3], LocalTime.parse(info[4]), LocalTime.parse(info[5]));

                matchUp.aggiungiStruttura(s);
 
            }

        }catch (Exception ex){

            ex.printStackTrace();

        }
 
 
        try(BufferedReader ftestoIn = new BufferedReader(new FileReader("gestori.txt"))){

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
 
            String[] info;

            while(ftestoIn.ready()){

                GregorianCalendar dataNascita = new GregorianCalendar();
 
                info = ftestoIn.readLine().split(",");
 
                Struttura s1 = matchUp.getStruttura(info[0]);
 
                dataNascita.setTime(dateFormat.parse(info[4]));

                Gestore g1 = new Gestore(info[2],info[3],dataNascita);

                g1.setId(Integer.parseInt(info[1])); 

				Struttura s = matchUp.getStruttura(info[0]);

                g1.setUsername(info[5]);

                g1.setPassword(info[6]);

                matchUp.getListaUtenti().add(g1);

            }
 
        }catch(Exception ex){

            ex.printStackTrace();

        }
 
 
        try(BufferedReader ftestoIn = new BufferedReader(new FileReader("campi.txt"))){

            String[] info;

            while(ftestoIn.ready()){
 
                info = ftestoIn.readLine().split(",");

                Struttura s = matchUp.getStruttura(info[0]);

                String categoria = info[2];

				String tipologia = info[3];

				double tariffa = Double.parseDouble(info[4]);

				s.inserisciCampo(categoria, tipologia, tariffa);

            }
 
        }catch(Exception ex){

            ex.printStackTrace();

        }
 
 
        try(BufferedReader ftestoIn = new BufferedReader(new FileReader("giocatori.txt"))){

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
 
            String[] info;

            while(ftestoIn.ready()){

                GregorianCalendar dataNascita = new GregorianCalendar();
 
                info = ftestoIn.readLine().split(",");

                dataNascita.setTime(dateFormat.parse(info[3]));

                Giocatore g1 = new Giocatore(info[1],info[2],dataNascita);

                g1.setUsername(info[4]);

                g1.setPassword(info[5]);

                matchUp.getListaUtenti().add(g1);

            }
 
        }catch(Exception ex){

            ex.printStackTrace();

        }
 
 
        try(BufferedReader ftestoIn = new BufferedReader(new FileReader("prenotazioni.txt"))){

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd:HH:mm");

            String[] info;
 
            while(ftestoIn.ready()){

                GregorianCalendar inizio = new GregorianCalendar();

                GregorianCalendar fine = new GregorianCalendar();
 
                info = ftestoIn.readLine().split(",");
 
                Struttura s1 = matchUp.getStruttura(info[0]);

                Giocatore g1 = (Giocatore)matchUp.ricercaUtente(info[5]);
 
                if(g1 != null){
 
                    inizio.setTime(dateFormat.parse(info[3]));

                    fine.setTime(dateFormat.parse(info[4]));

                    Prenotazione p = new Prenotazione(Integer.parseInt(info[1]), inizio, fine,g1,s1,s1.getCampo(Integer.parseInt(info[2])));

                    g1.incrementaNumeroPrenotazioniEffettuate();

                    matchUp.getCatalogoPrenotazioni().add(p);

                }

            }

        }catch (Exception ex){

            ex.printStackTrace();

        }
        for(int i = 0; i<matchUp.getCatalogoPrenotazioni().size();i++){

            System.out.println(matchUp.getCatalogoPrenotazioni().get(i).getId() + " data inizio" + matchUp.getCatalogoPrenotazioni().get(i).getDataInizio().getTime() + " data fine " + matchUp.getCatalogoPrenotazioni().get(i).getDataFine().getTime());

        }
        
    }
    
    /*é stato imposto che i test si svolgano in ordine tramite la direttiva @Order*/

    @Test
    @Order(1)
    void getInstance() {

        assertNotNull(MatchUp.getInstance());


    }

    @Test
    @Order(2)
    void login(){

        /*Test 1:
         * Set di dati:
         * Username: "Sebastiano1999"
         * Password: "PasswordGenerica"
         * Esito aspettato: false perchè l'utente non esiste*/
        assertFalse(matchUp.login("Salvo99", "password123!"));

        /*Test 2:
         * Username: "Mario05"
         * Password: "password12345"
         * Esito aspettato: false perchè la password è errata*/
        assertFalse(matchUp.login("Mario05", "password12345"));

        /*Test 3
         * Username: "Mario05"
         * Password: "password123!"
         * Esito aspettato: true perchè l'utente esiste e la password è corretta*/

        assertTrue(matchUp.login("Mario05", "password123!"));

    }

    @Test
    @Order(3)
    void effettuaRicercaStruttura() {

        /*Si prova a cercare come tipologia di campo "Calcio a 5". Risultato atteso: lista non vuota*/
        assertNotEquals("[]",matchUp.effettuaRicercaStruttura("calcio a 5").toString());

        /*Si prova a cercare come tipologia di campo "Calcio a 7". Risultato atteso: lista non vuota*/
        assertNotEquals("[]",matchUp.effettuaRicercaStruttura("calcio a 7").toString());

        /*Si prova a cercare come tipologia di campo "Calcio a 11". Risultato atteso: lista vuota*/
        assertEquals("[]", matchUp.effettuaRicercaStruttura("calcio a 11").toString());
    }

    @Test
    @Order(4)
    void mostraCampiStruttura() {
        /*Si prova a cercare i campi di una ipotetica struttura s1 non registrata su Matchup. Risultato atteso: lista vuota*/
        assertEquals("[]",matchUp.mostraCampiStruttura("A5").toString());

        /*Si prova a cercare i campi di una struttura s1 registrata su Matchup. Risultato atteso: lista non vuota*/
        assertNotEquals("[]",matchUp.mostraCampiStruttura("A1").toString());

    }

    @Test
    @Order(5)
    void prenotaCampo() {

        /*public boolean prenotaCampo(String codiceStruttura, int codiceCampo, GregorianCalendar dataInizio, GregorianCalendar dataFine)*/


        /*Test 1
        Set dei dati in test:
        * codiceStruttura: A1
        * codiceCampo: 1
        * dataInizio: 26 Novembre 15:00
        * dataFine: 26 Novembre 16:00
        Esito aspettato: true in quanto non ci sono prenotazioni per quel giorno e fascia oraria */
    	
        GregorianCalendar dataInizio1 = new GregorianCalendar();
        GregorianCalendar dataFine1 = new GregorianCalendar();
        dataInizio1.set(2026, Calendar.NOVEMBER, 26,15,0);
        dataFine1.set(2026, Calendar.NOVEMBER,26,16,0);

        assertTrue(matchUp.prenotaCampo("A1", 1, dataInizio1,dataFine1));

        /*Test 2*/
        /*Set dei dati in ingresso:
        * codiceStruttura: A1
        * codiceCampo: 4
        * dataInizio: 26 Novembre 15:00
        * dataFine: 26 Novemebre 16:00
        Esito aspettato: false in quanto il campo in ingresso non esiste */

        assertFalse(matchUp.prenotaCampo("A1", 4, dataInizio1,dataFine1));

        /*Test 3*/
        /*Set dei dati in ingresso:
        * codiceStruttura: A2
        * codiceCampo: 1
        * dataInizio: 26 Novembre 15:00
        * dataFine: 26 Novembre 16:00
        Esito aspettato: false in quanto la struttura non esiste */

        assertFalse(matchUp.prenotaCampo("A5", 1, dataInizio1,dataFine1));

        /*Test 4*/
        /*Set dei dati in ingresso:
        * codiceStruttura: A1
        * codiceCampo: 2
        * dataInizio: 26 Novembre 15:00
        * dataFine: 26 Novembre 17:00
        Esito aspettato: true in quanto il campo 2 risulta libero in quella fascia oraria */


        GregorianCalendar dataInizio2 = new GregorianCalendar();
        GregorianCalendar dataFine2 = new GregorianCalendar();
        dataInizio2.set(2023, Calendar.NOVEMBER, 26,15,0);
        dataFine2.set(2023, Calendar.NOVEMBER,26,17,0);

        assertTrue(matchUp.prenotaCampo("A1",2,dataInizio2,dataFine2));

        /*Test 5
         * Set dei dati in ingresso:
         * codiceStruttura: A1
         * codiceCampo 1
         * dataInizio: 29 Novembre 23:00
         * dataFine: 29 Novembre 00:00
         * Esito aspettato: false perchè la struttura risulta chiusa in quella fascia oraria*/

        GregorianCalendar dataInizio3 = new GregorianCalendar();
        GregorianCalendar dataFine3 = new GregorianCalendar();
        dataInizio3.set(2023, Calendar.NOVEMBER, 29,23,0);
        dataFine3.set(2023, Calendar.NOVEMBER,29,0,0);

        assertFalse(matchUp.prenotaCampo("A1", 1,dataInizio3,dataFine3));


    }

    @Test
    @Order(6)
    void confermaPrenotazione() {

        GregorianCalendar dataInizio = new GregorianCalendar();
        GregorianCalendar dataFine = new GregorianCalendar();
        dataInizio.set(2026, Calendar.NOVEMBER, 26,15,0);
        dataFine.set(2026, Calendar.NOVEMBER,26,16,0);

        matchUp.prenotaCampo("A1",1,dataInizio,dataFine);

        /*Esito aspettato: true perchè c'è una prenotazione in corso dalla funzione precedente prenotaCampo */
        assertTrue(matchUp.confermaPrenotazione());

        /*Esito aspettato: false in quanto non vi è una prenotazione in corso */
        assertFalse(matchUp.confermaPrenotazione());


    }



    @Test
    @Order(7)
    void istanziaNuovoUtente() throws AgeNotValidException {

        RegistrationHandlerFactory factory = RegistrationHandlerFactory.getInstance();

        /*Test 1: Creazione cliente con età inferiore a 14 anni
         * Nome = Mario
         * Cognome = Cipriano
         * Data nascita = 08-04-2014
         * Esito aspettato: Lancio eccezione Età non valida (cliente)*/
        GregorianCalendar dataNascita = new GregorianCalendar();
        dataNascita.set(2014,Calendar.APRIL,8);


        assertThrows(AgeNotValidException.class, () -> matchUp.istanziaNuovoUtente("Nome",
                "Cognome",dataNascita,factory.getGiocatoreHandler()));

        /*Test 2. Creazione di un gestore con età pari a 17 anni
        * stessi dati di prima ad eccezione della data di nascita: 08-04-2017
        * Esito aspettato: lancio di eccezione età non valida*/

        GregorianCalendar dataNascita2 = new GregorianCalendar();
        dataNascita2.set(2009, Calendar.APRIL,8);

        assertThrows(AgeNotValidException.class, () -> matchUp.istanziaNuovoUtente("Nome",
                "Cognome",dataNascita2,factory.getGestoreHandler()));


        /*Test 3. Creazione di un gestore con età pari a 20 anni.
         * Nome = Salvatore
         * Cognome = Campione
         * Data nascita = 15-11-2006
         * Esito aspettato: Creazione del gestore con successo */

        GregorianCalendar dataNascita3 = new GregorianCalendar();
        dataNascita3.set(2006, Calendar.NOVEMBER,15);

        matchUp.istanziaNuovoUtente("Nome", "Cognome",dataNascita3,factory.getGestoreHandler());
        assertNotNull(matchUp.getUtenteCorrente());

        /*Test 4. Creazione di un cliente con età pari a 17 anni.
        * Stessi dati precedenti.
        * Esito aspettato: Creazione del gestore con successo*/

        matchUp.istanziaNuovoUtente("Nome", "Cognome",dataNascita2,factory.getGiocatoreHandler());
        assertNotNull(matchUp.getUtenteCorrente());


    }

    @Test
    @Order(8)
    void confermaUtente() {

        /*Test 1.
        * Esito aspettato: true perchè l'utente corrente non è nullo a causa del run del test precedente
        */

        assertTrue(matchUp.confermaRegistrazioneUtente());

        /*Test 2.
        * Esito aspettato: false perchè l'utente corrente è nullo*/

        assertFalse(matchUp.confermaRegistrazioneUtente());

    }

    
    
    
    @Test
    @Order(9)
    void inserisciCredenziali() throws AgeNotValidException {
    	 
        /* Pre-condizione: avvio della procedura di registrazione per un nuovo utente */
        RegistrationHandlerFactory factory = RegistrationHandlerFactory.getInstance();

        GregorianCalendar dataNascita = new GregorianCalendar();
        dataNascita.set(2005, Calendar.AUGUST, 17);

        matchUp.istanziaNuovoUtente("Matteo", "Romano", dataNascita, factory.getGiocatoreHandler());


        // --- 1. TEST FALLIMENTO PER USERNAME GIÀ ESISTENTE ---
        /* Username "Rocco92" già registrato a sistema, anche se la password è valida -> esito atteso:false */
        assertFalse(matchUp.inserisciCredenziali("Rocco92", "Password123!"));


        // --- 2. TEST FALLIMENTO PER REGOLE PASSWORD (Username valido:) ---

        /* Caso A: Manca il carattere speciale ,esito atteso:false */
        assertFalse(matchUp.inserisciCredenziali("Matteo05", "Password123"));
              

        /* Caso B: Mancano i numeri ,esito atteso:false*/
        assertFalse(matchUp.inserisciCredenziali("Mario05", "Password!"));
              

        /* Caso C: Mancano le lettere esito atteso:false*/
        assertFalse(matchUp.inserisciCredenziali("Rocco92", "12345678!"));
                
        // --- 3. TEST SCENARIO DI SUCCESSO ---
        /* Username unico + Password valida, esito atteso:True */
        assertTrue(matchUp.inserisciCredenziali("Matteo05", "Password123!"));
              


        /* Disconnessione/reset della sessione di registrazione */
        matchUp.logout();
    }


    @Test
    @Order(11)
    void inserisciDatiStruttura() throws AgeNotValidException {

    	RegistrationHandlerFactory factory = RegistrationHandlerFactory.getInstance();

        GregorianCalendar dataNascita3 = new GregorianCalendar();
        dataNascita3.set(2003, Calendar.AUGUST,17);

        matchUp.istanziaNuovoUtente("Nome", "Cognome",dataNascita3,factory.getGestoreHandler());
        assertNotNull(matchUp.getUtenteCorrente());

        String codice = "A" + (matchUp.getMappaStrutture().size() + 1);
        Struttura s1 = new Struttura(codice ,"StrutturaProva","ViaDiProva10","3391628374",LocalTime.parse("08:00"),LocalTime.parse("21:00"));

        matchUp.inserisciDatiStruttura("StrutturaProva","ViaDiProva10","3391628374",LocalTime.parse("08:00"),LocalTime.parse("21:00"));
        assertEquals(matchUp.getStrutturaCorrente().toString(),s1.toString());
    }

    @Test
    @Order(12)
    void confermaRegistrazioneStruttura() {

        matchUp.inserisciCampoStruttura("Calcio a 5", "sintetico", 10);

        assertTrue(matchUp.confermaRegistrazioneStruttura());

        assertFalse(matchUp.confermaRegistrazioneStruttura());


    }

    @Test
    @Order(13)
    void richiediDisponibilità(){
        /*Prenotazioni del Campo 2 della Struttura A2 effettuate nel 25/09/2026*/
        /*
        A2,8,2,2026-09-25:10:00,2026-09-25:12:00,Giova66
        A2,9,2,2026-09-25:12:00,2026-09-25:13:00,Francesco08
        */

        Struttura s2= matchUp.getStruttura("A2");

        GregorianCalendar giornoScelto = new GregorianCalendar(2026,Calendar.SEPTEMBER,25);

        FasciaOraria fo = new FasciaOraria(s2.getOrarioApertura(),s2.getOrarioChiusura());
        //Relativa alla prima prenotazione
        fo.aggiornaFasciaOraria(10,11);
      //Relativa alla prima prenotazione
        fo.aggiornaFasciaOraria(11,12);
        //Relativa alla seconda prenotazione
        fo.aggiornaFasciaOraria(12,13);


        assertEquals(fo.toString(),matchUp.richiediDisponibilita(s2.getCodice(), s2.getCampo(2).getId(),giornoScelto).toString());

        //Relativa a una ipotetica prenotazione effettuata dalle 17 alle 18
        fo.aggiornaFasciaOraria(17,19);

        assertNotEquals(fo.toString(),matchUp.richiediDisponibilita(s2.getCodice(), s2.getCampo(2).getId(),giornoScelto).toString());

    }
}
    
    
    
    
    
    
    
    
  
 