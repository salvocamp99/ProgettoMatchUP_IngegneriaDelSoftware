package Main;

import Model.*;
import Eccezioni.AgeNotValidException;
import Eccezioni.NameNotValidException;
import Eccezioni.NumberNotValidException;

import java.io.BufferedReader;
import java.io.FileReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;

public class Main1 {

	public static void main(String[] args) {
		MatchUp matchUp = MatchUp.getInstance();
		inizializzaSistema(matchUp);
		menuGenerale(matchUp);
	}

	private static void menuGenerale(MatchUp matchUp) {
		Scanner s = new Scanner(System.in);
		int scelta;
		RegistrationHandlerFactory handlerFactory = RegistrationHandlerFactory.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		String nome, cognome, username, password, conferma;
		GregorianCalendar dataNascita = new GregorianCalendar();
		Date date = null;
		boolean continua, esito;

		do {
			System.out.println("(1) Per registrarsi come giocatore.");
			System.out.println("(2) Per registrarsi come gestore.");
			System.out.println("(3) Login");
			System.out.println("(0) Per terminare il programma.");
			scelta = s.nextInt();

			switch (scelta) {
			case 1:
				// Registrazione Giocatore (UC2)
				do {
					System.out.println("Inserisci nome");
					nome = s.next();
					System.out.println("Inserisci cognome");
					cognome = s.next();
					continua = true;
				    try {
				        matchUp.verificaValiditaNomeCognome(nome, cognome);
				    } catch (NameNotValidException e) {
				    	 conferma = "no";  
				        continue;
				        // il messaggio è già stampato dal costruttore dell'eccezione
				    }
				 
					do {
						System.out.println("Inserisci data di nascita nel formato dd-MM-yyyy");
						String dataStr = s.next();
						continua = true;
						try {
							date = dateFormat.parse(dataStr);
						} catch (ParseException e) {
							continua = false;
							System.out.println("Formato data errato.");
						}
					} while (!continua);
					dataNascita.setTime(date);

					try {
						matchUp.istanziaNuovoUtente(nome, cognome, dataNascita, handlerFactory.getGiocatoreHandler());
					} catch (AgeNotValidException e) {
						System.out
								.println("Età non valida per un giocatore (minimo 14 anni). Registrazione cancellata.");
						continua = false;
						break;
					}

					System.out.println("Confermi i dati inseriti? Digita si o no");
					conferma = s.next().toLowerCase();
					if (conferma.equals("no")) {
						System.out.println("Inserimento cancellato. Riprova.");
					} else if (!conferma.equals("si")) {
						System.out.println("Risposta non valida. Riprova.");
					}
				} while (conferma.equals("no") || !conferma.equals("si"));

				if (continua) {
					// Inserimento credenziali (contratto 2.6.2)
					do {
						System.out.println("Inserisci uno username");
						username = s.next();
						System.out.println("Inserisci una password (min 8 caratteri e carattere speciale)");
						password = s.next();
						esito = matchUp.inserisciCredenziali(username, password);
						if (!esito) {
							System.out.println("Username già esistente o password non valida. Riprova.");
						}
					} while (!esito);

					// Conferma registrazione giocatore (contratto 2.6.3)
					 Utente nuovoGiocatore = matchUp.getUtenteCorrente();
					if (matchUp.confermaRegistrazioneUtente()) {
						System.out.println("Giocatore registrato con successo con id " + nuovoGiocatore.getId() + ". Ora puoi accedere.");
					} else {
						System.out.println("Errore durante la registrazione.");
					}
				}
				break;

			case 2:
				// Registrazione Gestore (UC1)
				do {
					System.out.println("Inserisci nome");
					nome = s.next();
					System.out.println("Inserisci cognome");
					cognome = s.next();
					continua = true;
				    try {
				        matchUp.verificaValiditaNomeCognome(nome, cognome);
				    } catch (NameNotValidException e) {
				    	 conferma = "no";  
				        continue;
				        // il messaggio è già stampato dal costruttore dell'eccezione
				    }
				 
					do {
						System.out.println("Inserisci data di nascita nel formato dd-MM-yyyy");
						String dataStr = s.next();
						continua = true;
						try {
							date = dateFormat.parse(dataStr);
						} catch (ParseException e) {
							continua = false;
							System.out.println("Formato data errato.");
						}
					} while (!continua);
					dataNascita.setTime(date);

					try {
						matchUp.istanziaNuovoUtente(nome, cognome, dataNascita, handlerFactory.getGestoreHandler());
					} catch (AgeNotValidException e) {
						System.out.println("Età non valida per un gestore (minimo 18 anni). Registrazione cancellata.");
						continua = false;
						break;
					}

					System.out.println("Confermi i dati inseriti? Digita si o no");
					conferma = s.next().toLowerCase();
					if (conferma.equals("no")) {
						System.out.println("Inserimento cancellato. Riprova.");
					} else if (!conferma.equals("si")) {
						System.out.println("Risposta non valida. Riprova.");
					}
				} while (conferma.equals("no") || !conferma.equals("si"));

				if (continua) {
					// Inserimento credenziali (contratto 2.5.2)
					do {
						System.out.println("Inserisci uno username");
						username = s.next();
						System.out.println("Inserisci una password (min 8 caratteri e con carattere speciale)");
						password = s.next();
						esito = matchUp.inserisciCredenziali(username, password);
						if (!esito) {
							System.out.println("Username già esistente o password non valida. Riprova.");
						}
					} while (!esito);

					// Conferma registrazione gestore (contratto 2.5.3)
					Utente nuovoGestore = matchUp.getUtenteCorrente();
					if (matchUp.confermaRegistrazioneUtente()) {
						 System.out.println("Gestore registrato con id " + nuovoGestore.getId() + ". Ora inserisci i dati della struttura.");
					} else {
						System.out.println("Errore durante la registrazione del gestore.");
						break;
					}
                    s.nextLine(); 
					// Inserimento struttura (contratti 2.5.4, 2.5.5, 2.5.6)
					System.out.println("Inserisci il nome della struttura");
					String nomeStruttura = s.nextLine();
					System.out.println("Inserisci la località della struttura");
					String localitaStruttura = s.nextLine();

					String numeroTelefonoStruttura;
					do {
						System.out.println("Inserisci il numero di telefono (10 cifre)");
						numeroTelefonoStruttura = s.nextLine();
						continua = true;
						try {
							matchUp.verificaValiditaTelefono(numeroTelefonoStruttura);
						} catch (NumberNotValidException e) {
							continua = false;
							System.out.println("Numero non valido. Riprova.");
						}
					} while (!continua);

					System.out.println("Formato ora: 00-23, minuti: 00-59");
					System.out.println("Inserisci l'orario di apertura (hh:mm)");
					LocalTime orarioApertura = LocalTime.parse(s.nextLine());
					System.out.println("Inserisci l'orario di chiusura (hh:mm)");
					LocalTime orarioChiusura = LocalTime.parse(s.nextLine());

					matchUp.inserisciDatiStruttura(nomeStruttura, localitaStruttura, numeroTelefonoStruttura,
							orarioApertura, orarioChiusura);

					// Inserimento campi
					do {
						System.out.println("Inserisci la categoria del campo (es. calcio)");
						String categoria = s.nextLine();
						System.out.println("Inserisci la tipologia del campo (es. sintetico)");
						String tipologia = s.nextLine();
						System.out.println("Inserisci la tariffa oraria");
						String inputTariffa = s.nextLine().replace(',', '.');
						double tariffa = Double.parseDouble(inputTariffa);
						s.nextLine();
						matchUp.inserisciCampoStruttura(categoria, tipologia, tariffa);

						System.out.println("Vuoi inserire un altro campo? (si/no)");
						conferma = s.nextLine().toLowerCase();
					} while (conferma.equals("si"));

					if (matchUp.confermaRegistrazioneStruttura()) {
						System.out.println("Struttura registrata con successo!");
					} else {
						System.out.println("Errore nella registrazione della struttura.");
					}
				}
				break;

			case 3:
				System.out.println("Inserisci il tuo username");
				username = s.next();
				System.out.println("Inserisci la tua password");
				password = s.next();

				if (!matchUp.login(username, password)) {
					System.out.println("Credenziali errate! Riprova.");
				} else {
					System.out.println("Benvenuto: " + username);
					if (matchUp.getUtenteCorrente() instanceof Giocatore) {
						menuGiocatore(matchUp);
					} else if (matchUp.getUtenteCorrente() instanceof Gestore) {
						menuGestore(matchUp);
					}
				}
				break;

			case 0:
				System.out.println("Arrivederci!");
				break;

			default:
				System.out.println("Scelta non valida.");
				break;
			}
		} while (scelta != 0);
	}

	private static void menuGestore(MatchUp matchUp) {
		Scanner s = new Scanner(System.in);
	    int scelta = -1;

	    do {
	        System.out.println("\n--- MENU PRINCIPALE GESTORE ---");
	        System.out.println("(1) Per visualizzare le prenotazioni della tua struttura");
	        System.out.println("(0) Per effettuare il logout");
	        System.out.print("Inserisci la tua scelta: ");

	        try {
	            scelta = Integer.parseInt(s.nextLine().trim());
	        } catch (NumberFormatException e) {
	            System.out.println("Errore: Devi inserire un numero valido (1 o 0).");
	            continue;
	        }

	        switch (scelta) {
	            case 1:
	                // Richiama lo stesso metodo che in automatico riconosce il Gestore
	                LinkedList<Prenotazione> prenotazioni = matchUp.visualizzaPrenotazioni();
	                
	                if (prenotazioni == null || prenotazioni.isEmpty()) {
	                    System.out.println("Non ci sono prenotazioni registrate per la tua struttura.");
	                } else {
	                    System.out.println("\n--- PRENOTAZIONI EFFETTUATE NELLA TUA STRUTTURA ---");
	                    for (Prenotazione p : prenotazioni) {
	                        System.out.println("Prenotazione #" + p.getId() 
	                                + " - Campo: " + p.getCampo().getId() 
	                                + " - Giocatore: " + p.getGiocatore().getNome() + " " + p.getGiocatore().getCognome()
	                                + " - Dal " + p.getDataInizio().getTime() 
	                                + " al " + p.getDataFine().getTime() 
	                                + " - Prezzo: €" + p.getCostoTotale());
	                    }
	                }
	                break;

	            case 0:
	                matchUp.logout();
	                System.out.println("Logout effettuato.");
	                break;

	            default:
	                System.out.println("Scelta non valida.");
	                break;
	        }
	    } while (scelta != 0);
	}
	

	private static void menuGiocatore(MatchUp matchUp) {
		Scanner s = new Scanner(System.in);
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd");
		int scelta = -1, idCampo, orarioInizio, orarioFine;
		String categoriaCampo, codiceStruttura, conferma, dataStr;
		LinkedList<Struttura> listaStrutture;
		LinkedList<Campo> listaCampi;
		GregorianCalendar dataDesiderata = new GregorianCalendar();
		GregorianCalendar dataInizio = new GregorianCalendar();
		GregorianCalendar dataFine = new GregorianCalendar();
		Date date = new Date();
		boolean continua, esito;

		do {
			System.out.println("\n--- MENU PRINCIPALE GIOCATORE ---");
			System.out.println("(1) Per effettuare una prenotazione");
			System.out.println("(2) Per visualizzare le tue prenotazioni");
			System.out.println("(0) Per effettuare il logout");
			System.out.print("Inserisci la tua scelta: ");

			// Lettura sicura della scelta
			try {
				scelta = Integer.parseInt(s.nextLine().trim());
			} catch (NumberFormatException e) {
				System.out.println("Errore: Devi inserire un numero valido (1, 2 o 0).");
				continue;
			}

			switch (scelta) {
			case 1:
				System.out.println("Inserisci il tipo di campo da prenotare (es. calcio a 5):");
				categoriaCampo = s.nextLine().trim().toLowerCase(); // Supporta frasi con spazi

				listaStrutture = matchUp.effettuaRicercaStruttura(categoriaCampo);

				if (listaStrutture == null || listaStrutture.isEmpty()) {
					System.out.println("Nessuna struttura offre questo tipo di campo.");
					break;
				}

				for (Struttura struttura : listaStrutture) {
					struttura.formattedPrint();
				}

				System.out.println("Inserisci il codice della struttura scelta:");
				codiceStruttura = s.nextLine().trim().toUpperCase();

				listaCampi = matchUp.mostraCampiStruttura(codiceStruttura);
				if (listaCampi == null || listaCampi.isEmpty()) {
					System.out.println("Struttura non trovata o senza campi.");
					break;
				}

				for (Campo campo : listaCampi) {
					System.out
							.println("Id: " + campo.getId() + " - Categoria: " + campo.getCategoria() + " - Tipologia: "
									+ campo.getTipologia() + " - TariffaOraria: " + campo.getTariffaOraria());
				}

				System.out.println("Inserisci il codice del campo:");
				try {
					idCampo = Integer.parseInt(s.nextLine().trim());
				} catch (NumberFormatException e) {
					System.out.println("Codice campo non valido. Ritorno al menu.");
					break;
				}

				// Controllo esistenza campo
				Struttura strutturaScelta = matchUp.getStruttura(codiceStruttura);
				if (strutturaScelta == null || strutturaScelta.getCampo(idCampo) == null) {
					System.out.println("Campo non trovato.");
					break;
				}

				// Scelta data
				do {
					System.out.println("Inserisci la data da prenotare nel formato MM-dd (es. 05-20):");
					dataStr = s.nextLine().trim();
					continua = true;
					try {
						date = dateFormat.parse(dataStr);
					} catch (ParseException e) {
						continua = false;
						System.out.println("Formato data errato. Riprova.");
					}
				} while (!continua);

				String[] parti = dataStr.split("-");
				int mese = Integer.parseInt(parti[0]) - 1;
				int giorno = Integer.parseInt(parti[1]);
				dataDesiderata.set(LocalDateTime.now().getYear(), mese, giorno);

				// Visualizzazione fasce orarie
				FasciaOraria fo = matchUp.richiediDisponibilita(codiceStruttura, idCampo, dataDesiderata);
				if (fo == null) {
					System.out.println("Impossibile recuperare le fasce orarie.");
					break;
				}
				System.out.println("Fasce orarie disponibili per il campo selezionato:");
				System.out.println(fo.toString());

				// Scelta orario
				do {
					try {
						System.out.println("Inserisci l'ora di inizio (0-23):");
						orarioInizio = Integer.parseInt(s.nextLine().trim());
						System.out.println("Inserisci l'ora di fine (0-23):");
						orarioFine = Integer.parseInt(s.nextLine().trim());
					} catch (NumberFormatException e) {
						System.out.println("Inserisci un numero intero valido per gli orari.");
						esito = false;
						continue;
					}

					dataInizio.set(LocalDateTime.now().getYear(), mese, giorno, orarioInizio, 0);
					dataFine.set(LocalDateTime.now().getYear(), mese, giorno, orarioFine, 0);

					esito = matchUp.prenotaCampo(codiceStruttura, idCampo, dataInizio, dataFine);
					if (!esito) {
						System.out.println("Fascia oraria non disponibile o non valida.");
					}
				} while (!esito);

				// Conferma prenotazione
				do {
					System.out.println("Confermi la prenotazione? (si/no)");
					conferma = s.nextLine().trim().toLowerCase();
					if (conferma.equals("no")) {
						System.out.println("Prenotazione annullata.");
						break;
					} else if (conferma.equals("si")) {
						if (matchUp.confermaPrenotazione()) {
							System.out.println("Prenotazione confermata!");
						} else {
							System.out.println("Errore nella conferma della prenotazione.");
						}
					} else {
						System.out.println("Risposta non valida.");
					}
				} while (!conferma.equals("si") && !conferma.equals("no"));
				break;

			case 2:
			    System.out.println("\n--- LE TUE PRENOTAZIONI ---");
			    LinkedList<Prenotazione> prenotazioni = matchUp.visualizzaPrenotazioni();

			    if (prenotazioni == null || prenotazioni.isEmpty()) {
			        System.out.println("Non hai ancora effettuato alcuna prenotazione.");
			    } else {
			        for (Prenotazione p : prenotazioni) {
			            System.out.println("Prenotazione #" + p.getId() 
			                    + " - Struttura: " + p.getStruttura().getNome() 
			                    + " (" + p.getStruttura().getLocalita() + ")"
			                    + " - Campo: " + p.getCampo().getId() 
			                    + " - Dal " + p.getDataInizio().getTime() 
			                    + " al " + p.getDataFine().getTime() 
			                    + " - Costo Totale: €" + String.format("%.2f", p.getCostoTotale()));
			        }
			    }
               break;
			case 0:
				matchUp.logout();
				System.out.println("Logout effettuato.");
				break;

			default:
				System.out.println("Scelta non valida.");
				break;
			}
		} while (scelta != 0);
	}

	private static void inizializzaSistema(MatchUp matchUp) {
		// Caricamento strutture
		try (BufferedReader br = new BufferedReader(new FileReader("strutture.txt"))) {
			String line;
			while ((line = br.readLine()) != null) {
				String[] info = line.split(",");
				Struttura s = new Struttura(info[0], info[1], info[2], info[3], LocalTime.parse(info[4]),
						LocalTime.parse(info[5]));
				matchUp.aggiungiStruttura(s);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		// Caricamento gestori (e collegamento alla struttura)
		try (BufferedReader br = new BufferedReader(new FileReader("gestori.txt"))) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			String line;
			while ((line = br.readLine()) != null) {
				String[] info = line.split(",");
				// info[0]=codiceStrutturaGestita, info[1]=id ,info[2]=nome, info[3]=cognome,
				// info[4]=dataNascita, info[5]=username, info[6]=password
				GregorianCalendar dataNascita = new GregorianCalendar();
				dataNascita.setTime(dateFormat.parse(info[4]));
				Gestore g = new Gestore(info[2], info[3], dataNascita);
				g.setId(Integer.parseInt(info[1])); 
				Struttura s = matchUp.getStruttura(info[0]);
				if (s != null) {
					g.setStruttura(s);
				}
				g.setUsername(info[5]);
				g.setPassword(info[6]);
				matchUp.getListaUtenti().add(g);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		// Caricamento campi
		try (BufferedReader br = new BufferedReader(new FileReader("campi.txt"))) {
			String line;
			while ((line = br.readLine()) != null) {
				String[] info = line.split(",");
				// info[0]=codiceStruttura, info[1]=idCampo,
				// info[2]=categoria,info[3]=tipologia, info[4]=tariffaOraria
				Struttura s = matchUp.getStruttura(info[0]);
				if (s != null) {
					// Ora usa il metodo con 3 parametri: categoria, tipologia, tariffa

					String categoria = info[2];
					String tipologia = info[3];
					double tariffa = Double.parseDouble(info[4]);
					s.inserisciCampo(categoria, tipologia, tariffa);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		// Caricamento giocatori
		try (BufferedReader br = new BufferedReader(new FileReader("giocatori.txt"))) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			String line;
			while ((line = br.readLine()) != null) {
				String[] info = line.split(",");
				// info[0]=id, info[1]=nome, info[2]=cognome, info[3]=dataNascita,
				// info[4]=username, info[5]=password
				GregorianCalendar dataNascita = new GregorianCalendar();
				dataNascita.setTime(dateFormat.parse(info[3]));
				Giocatore g = new Giocatore(info[1], info[2], dataNascita);
				g.setId(Integer.parseInt(info[0]));   
				g.setUsername(info[4]);
				g.setPassword(info[5]);
				matchUp.getListaUtenti().add(g);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		// Caricamento prenotazioni
		try (BufferedReader br = new BufferedReader(new FileReader("prenotazioni.txt"))) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd:HH:mm");
			String line;
			while ((line = br.readLine()) != null) {
				String[] info = line.split(",");
				// info[0]=codiceStruttura, info[1]=codicePrenotazione, info[2]=codiceCampo,
				// info[3]=dataInizio, info[4]=dataFine, info[5]=username
				Struttura s = matchUp.getStruttura(info[0]);
				Giocatore giocatore = (Giocatore) matchUp.ricercaUtente(info[5]);
				if (s != null && giocatore != null) {
					GregorianCalendar inizio = new GregorianCalendar();
					GregorianCalendar fine = new GregorianCalendar();
					inizio.setTime(dateFormat.parse(info[3]));
					fine.setTime(dateFormat.parse(info[4]));
					Campo campo = s.getCampo(Integer.parseInt(info[2]));
					if (campo != null) {
						Prenotazione p = new Prenotazione(Integer.parseInt(info[1]), inizio, fine, giocatore, s, campo);
						giocatore.incrementaNumeroPrenotazioniEffettuate();
						matchUp.getCatalogoPrenotazioni().add(p);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		int maxIdGiocatore = -1;
		int maxIdGestore = -1;
		for (Utente u : matchUp.getListaUtenti()) {
		    if (u instanceof Giocatore && u.getId() > maxIdGiocatore) {
		        maxIdGiocatore = u.getId();
		    } else if (u instanceof Gestore && u.getId() > maxIdGestore) {
		        maxIdGestore = u.getId();
		    }
		}
		Giocatore.allineaContatore(maxIdGiocatore + 1);
		Gestore.allineaContatore(maxIdGestore + 1);
	}
	
}
