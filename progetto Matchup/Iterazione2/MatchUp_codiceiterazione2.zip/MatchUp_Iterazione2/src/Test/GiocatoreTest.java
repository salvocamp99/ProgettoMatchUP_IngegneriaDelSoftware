package Test;

import Model.Giocatore;
import org.junit.jupiter.api.*;

import java.util.Calendar;
import java.util.GregorianCalendar;

import static org.junit.jupiter.api.Assertions.*;


@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class GiocatoreTest {
    Giocatore g1;

    @BeforeEach
    void setUp() {

        GregorianCalendar dataNascita = new GregorianCalendar();
        dataNascita.set(1999, Calendar.AUGUST, 17);
        g1 = new Giocatore("Mario", "Rossi", dataNascita);
        g1.setUsername("Mario05");
        g1.setPassword("password123!");

    }


    @Test
    void incrementoConteggiPrenotazioni() {

        g1.incrementaNumeroPrenotazioniEffettuate();
        assertEquals(1, g1.getNumeroPrenotazioniEffettuate());

        g1.incrementaNumeroPrenotazioniEffettuate();
        assertEquals(2, g1.getNumeroPrenotazioniEffettuate());

    }
}