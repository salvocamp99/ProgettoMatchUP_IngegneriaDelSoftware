package Test;

import Model.*;

import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;
 
import java.io.BufferedReader;

import java.io.FileReader;

import java.text.SimpleDateFormat;

import java.time.LocalTime;

import java.util.Calendar;

import java.util.GregorianCalendar;

import java.util.LinkedList;

import java.util.Map;
 
import static org.junit.jupiter.api.Assertions.*;
 
class StrutturaTest {
 
    Struttura s1;
 
    @BeforeEach

    void setUp() {
 
        MatchUp matchUp = MatchUp.getInstance();
 
        try(BufferedReader ftestoIn = new BufferedReader(new FileReader("strutture.txt"))){

            String[] info;

            while(ftestoIn.ready()){
 
                info = ftestoIn.readLine().split(",");

                Struttura s = new Struttura(info[0], info[1], info[2], info[3], LocalTime.parse(info[4]), LocalTime.parse(info[5]));

                matchUp.aggiungiStruttura(s);
 
            }

        }catch (Exception ex){

            ex.printStackTrace();

        }
 
 
        try(BufferedReader ftestoIn = new BufferedReader(new FileReader("gestori.txt"))){

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
 
            String[] info;

            while(ftestoIn.ready()){

                GregorianCalendar dataNascita = new GregorianCalendar();
 
                info = ftestoIn.readLine().split(",");
 
                Struttura s1 = matchUp.getStruttura(info[0]);
 
                dataNascita.setTime(dateFormat.parse(info[4]));

                Gestore g1 = new Gestore(info[2],info[3],dataNascita);

                g1.setId(Integer.parseInt(info[1])); 

				Struttura s = matchUp.getStruttura(info[0]);

                g1.setUsername(info[5]);

                g1.setPassword(info[6]);

                matchUp.getListaUtenti().add(g1);

            }
 
        }catch(Exception ex){

            ex.printStackTrace();

        }
 
 
        try(BufferedReader ftestoIn = new BufferedReader(new FileReader("campi.txt"))){

            String[] info;

            while(ftestoIn.ready()){
 
                info = ftestoIn.readLine().split(",");

                Struttura s = matchUp.getStruttura(info[0]);

                String categoria = info[2];

				String tipologia = info[3];

				double tariffa = Double.parseDouble(info[4]);

				s.inserisciCampo(categoria, tipologia, tariffa);

            }
 
        }catch(Exception ex){

            ex.printStackTrace();

        }
 
 
        try(BufferedReader ftestoIn = new BufferedReader(new FileReader("giocatori.txt"))){

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
 
            String[] info;

            while(ftestoIn.ready()){

                GregorianCalendar dataNascita = new GregorianCalendar();
 
                info = ftestoIn.readLine().split(",");

                dataNascita.setTime(dateFormat.parse(info[3]));

                Giocatore g1 = new Giocatore(info[1],info[2],dataNascita);

                g1.setUsername(info[4]);

                g1.setPassword(info[5]);

                matchUp.getListaUtenti().add(g1);

            }
 
        }catch(Exception ex){

            ex.printStackTrace();

        }
 
 
        try(BufferedReader ftestoIn = new BufferedReader(new FileReader("prenotazioni.txt"))){

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd:HH:mm");

            String[] info;
 
            while(ftestoIn.ready()){

                GregorianCalendar inizio = new GregorianCalendar();

                GregorianCalendar fine = new GregorianCalendar();
 
                info = ftestoIn.readLine().split(",");
 
                Struttura s1 = matchUp.getStruttura(info[0]);

                Giocatore g1 = (Giocatore)matchUp.ricercaUtente(info[5]);
 
                if(g1 != null){
 
                    inizio.setTime(dateFormat.parse(info[3]));

                    fine.setTime(dateFormat.parse(info[4]));

                    Prenotazione p = new Prenotazione(Integer.parseInt(info[1]), inizio, fine,g1,s1,s1.getCampo(Integer.parseInt(info[2])));

                    g1.incrementaNumeroPrenotazioniEffettuate();

                    matchUp.getCatalogoPrenotazioni().add(p);

                }

            }

        }catch (Exception ex){

            ex.printStackTrace();

        }
 
 
        GregorianCalendar[] array = new GregorianCalendar[14];

        for(int i = 0; i<8;i++){

            array[i] = new GregorianCalendar();

        }
 
        array[0].set(2026,Calendar.NOVEMBER,26,11,0);

        array[1].set(2026,Calendar.NOVEMBER,26,12,0);

        array[2].set(2026,Calendar.NOVEMBER,26,9,0);

        array[3].set(2026,Calendar.NOVEMBER,26,11,0);

        array[4].set(2026,Calendar.NOVEMBER,26,12,0);

        array[5].set(2026,Calendar.NOVEMBER,26,15,0);

        array[6].set(2026,Calendar.NOVEMBER,26,8,0);

        array[7].set(2026,Calendar.NOVEMBER,26,11,0);
 
        /*Aggiungo un set prenotazioni ai campi 1 e 2 della struttura A1*/

        s1 = matchUp.getStruttura("A1");

        Campo c1 = s1.getCampo(1);

        Campo c2 = s1.getCampo(2);
 
        GregorianCalendar dataNascita = new GregorianCalendar(1999,Calendar.APRIL,7);

        Giocatore g2 = new Giocatore("Mario","Cipriano",dataNascita);
 
        /*Prenotazione del campo 1 dalle 11 alle 12*/

        Prenotazione p1 = new Prenotazione(matchUp.getCatalogoPrenotazioni().size() + 1 ,array[0], array[1],g2, s1, c1);

        //c1.getListaPrenotazioniCampo().add(p1);

        matchUp.getCatalogoPrenotazioni().add(p1);
 
        /*Prenotazione del campo 2 dalle 9 alle 11*/

        Prenotazione p2 = new Prenotazione(matchUp.getCatalogoPrenotazioni().size() + 1,array[2], array[3],g2,s1,c2);

        matchUp.getCatalogoPrenotazioni().add(p2);
 
        /*Prenotazione del campo 2 dalle 12 alle 15*/

        Prenotazione p3 = new Prenotazione(matchUp.getCatalogoPrenotazioni().size() + 1, array[4], array[5],g2,s1,c2);

        matchUp.getCatalogoPrenotazioni().add(p3);
 
        /*Prenotazione del campo 1 dalle 8 alle 11*/

        Prenotazione p4 = new Prenotazione(matchUp.getCatalogoPrenotazioni().size() + 1 ,array[6], array[7],g2,s1,c1);

        matchUp.getCatalogoPrenotazioni().add(p4);
 
    }
 
    @Test

    void controllaDisponibilitaStruttura() {
 
        GregorianCalendar[] array = new GregorianCalendar[14];

        for(int i = 0; i<4;i++){

            array[i] = new GregorianCalendar();

        }
 
        array[0].set(2026, Calendar.NOVEMBER,26,11, 0);

        array[1].set(2026, Calendar.NOVEMBER,26,12, 0);

        array[2].set(2026, Calendar.NOVEMBER,26,1, 0);

        array[3].set(2026, Calendar.NOVEMBER,26,3, 0);
 
 
        /*Verifica prima coppia: prenotazione dalle 11:00 alle 12:00 che deve ritornare true*/
 
        assertTrue(s1.controllaDisponibilitaStruttura(array[0],array[1]));
 
        /*Verifica seconda coppia: prenotazione dalle 9:00 alle 11:00 che deve ritornare false */

        assertFalse(s1.controllaDisponibilitaStruttura(array[2],array[3]));
 
 
    }
 
    @Test

    void verificaCategoria() {
 
        /*Si prova a cercare come categoria di campo "Calcio a 5 ". Risultato atteso: true*/

        assertTrue(s1.verificaCategoria("calcio a 5"));
 
        /*Si prova a cercare come categoria di campo "calcio a 7". Risultato atteso: true*/

        assertTrue(s1.verificaCategoria("calcio a 7"));
 
        /*Si prova a cercare come categoria di campo "Calcio a 11". Risultato atteso: false*/

        assertFalse(s1.verificaCategoria("calcio a 11"));
 
    }
 
 
    @Test

    void getTariffaOraria() {
 
        /*La funzione restituisce la tariffa oraria del campo, se esiste.

        * -1 altrimenti*/
 
        /*Test 1:

        * codiceCampo = 1 valore atteso 5.00. */

        assertEquals(5.00, s1.getTariffaOraria(1));
 
        /*Test 2:

        * codiceCampo = 3 valore atteso 6.00*/
 
        assertEquals(6.00, s1.getTariffaOraria(3));
 
        /*Test 3:

        * codiceCampo = 4. Valore atteso -1*/

        assertEquals(-1, s1.getTariffaOraria(4));

    }
 
    @Test

    void getCampo() {

        /*Verifico che il campo di codice 1 esista: risultato atteso vero*/

        assertNotNull(s1.getCampo(1));
 
        /*Verifico che il campo di codice 2 esista: risultato atteso vero*/

        assertNotNull(s1.getCampo(2));
 
        /*Verifico che il campo di codice 3 esista: risultato atteso Falso*/

        assertNull(s1.getCampo(4));

    }
 
 
}
    