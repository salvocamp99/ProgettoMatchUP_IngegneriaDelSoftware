package Interface;

import java.util.GregorianCalendar;

public interface IRegistrationStrategy {
	boolean controllaEta(GregorianCalendar dataNascita);
}

