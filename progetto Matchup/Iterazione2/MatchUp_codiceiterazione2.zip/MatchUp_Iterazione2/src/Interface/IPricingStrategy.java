package Interface;

import java.util.GregorianCalendar;

public interface IPricingStrategy {
	public Double applicaSconto(Double prezzo, GregorianCalendar dataInizio, GregorianCalendar dataFine, int numeroPrenotazioniEffettuate);
}
