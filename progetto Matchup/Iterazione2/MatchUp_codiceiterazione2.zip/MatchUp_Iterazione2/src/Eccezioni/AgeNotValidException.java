package Eccezioni;

import Model.Utente;

public class AgeNotValidException extends Exception {
    private Utente utente;

    public AgeNotValidException(Utente utente) {
        super("Età non valida per la registrazione");
        this.utente = utente;
    }

    public Utente getUtente() {
        return utente;
    }
}