package Eccezioni;

public class NameNotValidException extends Exception{

    public NameNotValidException(){

        System.out.println("Nome o cognome non validi! Devono contenere solo lettere (minimo 2 caratteri).");
    }

}