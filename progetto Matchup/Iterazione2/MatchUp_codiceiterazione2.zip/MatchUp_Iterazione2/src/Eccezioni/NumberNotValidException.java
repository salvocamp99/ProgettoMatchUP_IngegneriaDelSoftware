package Eccezioni;

public class NumberNotValidException extends Exception {
    public NumberNotValidException() {
        super("Numero di telefono non valido");
    }
}