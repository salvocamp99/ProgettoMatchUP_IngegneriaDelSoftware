package Model;

import java.util.GregorianCalendar;


import Interface.IRegistrationStrategy;


public class Gestore extends Utente {
	private static int contatoreId=0;
	private Struttura struttura;
	public Gestore() {}
	public Gestore(String nome, String cognome, GregorianCalendar dataNascita) {
		super(nome, cognome, dataNascita, new GestoreStrategy());
		// TODO Auto-generated constructor stub
	
	}
	public Struttura getStruttura() {
		return struttura;
	}
	public void setStruttura(Struttura struttura) {
		this.struttura = struttura;
	}
	@Override
	public String toString() {
		 return "Gestore{" + super.toString() +
	               ", strutturaGestita=" + struttura +
	               '}';
	}
	
	
	public static int getProssimoId(){
	    return contatoreId++;
	}
	public static void allineaContatore(int minimoSuccessivo){
        if(minimoSuccessivo > contatoreId){
            contatoreId = minimoSuccessivo;
        }
    }
}





