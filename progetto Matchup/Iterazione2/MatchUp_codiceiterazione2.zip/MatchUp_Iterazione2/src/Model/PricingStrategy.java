package Model;

import Interface.IPricingStrategy;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class PricingStrategy implements IPricingStrategy {
    private int convertiOraChiusura(int oraChiusura) {
        return oraChiusura == 0 ? 24 : oraChiusura;
    }

    @Override
    public Double applicaSconto(Double prezzo, GregorianCalendar dataInizio, GregorianCalendar dataFine,
                                int numeroPrenotazioniEffettuate) {
        double prezzoScontato = prezzo;

        // Giorni festivi
        if (dataInizio.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY ||
            dataInizio.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
            prezzoScontato += 0.15 * prezzo;
        } else {
            // Fascia ridotta 9-12 o 14-16
            int inizio = dataInizio.get(Calendar.HOUR_OF_DAY);
            int fine = convertiOraChiusura(dataFine.get(Calendar.HOUR_OF_DAY));
            if ((inizio >= 9 && fine <= 12) || (inizio >= 14 && fine <= 16)) {
                prezzoScontato -= 0.1 * prezzo;
            }
        }

        // Sconto fedeltà ogni 4 prenotazioni
        int numeroPrenotazioneCorrente = numeroPrenotazioniEffettuate + 1;
        if (numeroPrenotazioneCorrente % 3 == 0) {
            prezzoScontato -= 0.15 * prezzoScontato;
        }
        return prezzoScontato;
    }
}