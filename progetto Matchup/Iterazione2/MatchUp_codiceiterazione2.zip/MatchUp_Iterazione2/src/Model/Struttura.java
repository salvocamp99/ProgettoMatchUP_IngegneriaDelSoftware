package Model;

import java.io.Serializable;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.LinkedList;

public class Struttura implements Serializable {
    private String codice;
    private String nome;
    private String localita;
    private String numeroTelefono;
    private LocalTime orarioApertura;
    private LocalTime orarioChiusura;
    private LinkedList<Campo> listaCampiStruttura;

    public Struttura() {
        listaCampiStruttura = new LinkedList<>();
    }

    public Struttura(String codice, String nome, String localita, String numeroTelefono,
                     LocalTime orarioApertura, LocalTime orarioChiusura) {
        this.codice = codice;
        this.nome = nome;
        this.localita = localita;
        this.numeroTelefono = numeroTelefono;
        this.orarioApertura = orarioApertura;
        this.orarioChiusura = orarioChiusura;
        this.listaCampiStruttura = new LinkedList<>();
    }

    // ========== GETTER E SETTER ==========
    public String getCodice() { return codice; }
    public void setCodice(String codice) { this.codice = codice; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getLocalita() { return localita; }
    public void setLocalita(String localita) { this.localita = localita; }
    public String getNumeroTelefono() { return numeroTelefono; }
    public void setNumeroTelefono(String numeroTelefono) { this.numeroTelefono = numeroTelefono; }
    public LocalTime getOrarioApertura() { return orarioApertura; }
    public void setOrarioApertura(LocalTime orarioApertura) { this.orarioApertura = orarioApertura; }
    public LocalTime getOrarioChiusura() { return orarioChiusura; }
    public void setOrarioChiusura(LocalTime orarioChiusura) { this.orarioChiusura = orarioChiusura; }
    public LinkedList<Campo> getListaCampiStruttura() { return listaCampiStruttura; }
    public void setListaCampiStruttura(LinkedList<Campo> listaCampiStruttura) { this.listaCampiStruttura = listaCampiStruttura; }

    // ========== METODI DI UTILITÀ ==========
    private int convertiOraChiusura(int oraChiusura) {
        return oraChiusura == 0 ? 24 : oraChiusura;
    }

    /**
     * Verifica se la struttura è aperta nell'intervallo richiesto
     */
    public boolean controllaDisponibilitaStruttura(GregorianCalendar dataInizio, GregorianCalendar dataFine) {
        int inizio = dataInizio.get(Calendar.HOUR_OF_DAY);
        int fine = convertiOraChiusura(dataFine.get(Calendar.HOUR_OF_DAY));
        return inizio >= orarioApertura.getHour() && fine <= convertiOraChiusura(orarioChiusura.getHour());
    }

    /**
     * Verifica se la struttura ha un campo con la categoria specificata
     */
    public boolean verificaCategoria(String categoriaCampo) {
        for (Campo c : listaCampiStruttura) {
            if (c.getCategoria().equalsIgnoreCase(categoriaCampo)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Restituisce il campo con l'id specificato
     */
    public Campo getCampo(int idCampo) {
        for (Campo c : listaCampiStruttura) {
            if (c.getId() == idCampo) {
                return c;
            }
        }
        return null;
    }

    /**
     * Aggiunge un nuovo campo alla struttura
     */
    public void inserisciCampo(String categoria, String tipologia, double tariffaOraria) {
        int nuovoId = listaCampiStruttura.size() + 1;
        listaCampiStruttura.add(new Campo(nuovoId, categoria, tipologia, tariffaOraria));
    }

    
    /**
     * Restituisce la tariffa oraria di un campo
     */
    public double getTariffaOraria(int idCampo) {
        Campo c = getCampo(idCampo);
        return (c != null) ? c.getTariffaOraria() : -1.0;
    }

    /**
     * Stampa formattata dei dati della struttura
     */
    public void formattedPrint() {
        System.out.println("---------------------------");
        System.out.println("Codice Struttura: " + codice);
        System.out.println("Nome struttura: " + nome);
        System.out.println("Localita: " + localita);
        System.out.println("Numero di telefono: " + numeroTelefono);
        System.out.println("Orario apertura: " + orarioApertura);
        System.out.println("Orario chiusura: " + orarioChiusura);
        System.out.println("---------------------------");
    }

    @Override
    public String toString() {
        return "Struttura{" + "codice='" + codice + '\'' + ", nome='" + nome + '\'' +
               ", localita='" + localita + '\'' + ", numeroTelefono='" + numeroTelefono + '\'' +
               ", orarioApertura=" + orarioApertura + ", orarioChiusura=" + orarioChiusura +
               ", listaCampiStruttura=" + listaCampiStruttura + '}';
    }
}