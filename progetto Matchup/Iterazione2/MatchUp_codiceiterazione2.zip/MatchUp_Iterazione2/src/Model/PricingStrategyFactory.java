package Model;

import Interface.IPricingStrategy;

public class PricingStrategyFactory {
    private static PricingStrategyFactory factory;

    private PricingStrategyFactory() {}

    public static PricingStrategyFactory getInstance() {
        if (factory == null) factory = new PricingStrategyFactory();
        return factory;
    }

    public IPricingStrategy getPricingStrategy() {
        return new PricingStrategy();
    }
}