package Model;

import Interface.IRegistrationStrategy;

public class RegistrationStrategyFactory {
    private static RegistrationStrategyFactory factory;

    private RegistrationStrategyFactory() {}

    public static RegistrationStrategyFactory getInstance() {
        if (factory == null) factory = new RegistrationStrategyFactory();
        return factory;
    }

    public IRegistrationStrategy getGiocatoreStrategy() {
        return new GiocatoreStrategy();
    }

    public IRegistrationStrategy getGestoreStrategy() {
        return new GestoreStrategy();
    }
}