package Model;

import java.util.GregorianCalendar;

public class RegistrationGiocatoreHandler extends RegistrationHandler{
	@Override
    public Utente nuovoUtente(String nome, String cognome, GregorianCalendar dataNascita) {
        return new Giocatore(nome, cognome, dataNascita);
    }
	
}