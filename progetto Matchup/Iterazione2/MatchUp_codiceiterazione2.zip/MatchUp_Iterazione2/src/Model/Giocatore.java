package Model;

import java.util.GregorianCalendar;

public class Giocatore extends Utente{
	private int numeroPrenotazioniEffettuate;
	private static int contatoreId=0;
	public Giocatore() {
		this.numeroPrenotazioniEffettuate=0;
		
	}
	
	public Giocatore(String nome, String cognome, GregorianCalendar dataNascita) {
		super(nome,cognome,dataNascita, new GiocatoreStrategy());
	    this.numeroPrenotazioniEffettuate=0;
}

	public int getNumeroPrenotazioniEffettuate() {
		return numeroPrenotazioniEffettuate;
	}

	public void setNumeroPrenotazioniEffettuate(int numeroPrenotazioniEffettuate) {
		this.numeroPrenotazioniEffettuate = numeroPrenotazioniEffettuate;
	}
	
	public void incrementaNumeroPrenotazioniEffettuate() {
		this.numeroPrenotazioniEffettuate++;
	}

	@Override
	public String toString() {
		 return "Giocatore{" + super.toString() +
	               ", numeroPrenotazioniEffettuate=" + numeroPrenotazioniEffettuate +
	               '}';
	}
	
	public static int getProssimoId(){
	    return contatoreId++;
	}
	public static void allineaContatore(int minimoSuccessivo){
        if(minimoSuccessivo > contatoreId){
            contatoreId = minimoSuccessivo;
        }
    }
	
}