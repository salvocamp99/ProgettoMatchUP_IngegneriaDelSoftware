package Model;

import java.time.LocalTime;

public class FasciaOraria {
    private static final int MEZZANOTTE_UNA = 0;
    private static final int UNA_DUE = 1;
    private static final int DUE_TRE = 2;
    private static final int TRE_QUATTRO = 3;
    private static final int QUATTRO_CINQUE = 4;
    private static final int CINQUE_SEI = 5;
    private static final int SEI_SETTE = 6;
    private static final int SETTE_OTTO = 7;
    private static final int OTTO_NOVE = 8;
    private static final int NOVE_DIECI = 9;
    private static final int DIECI_UNDICI = 10;
    private static final int UNDICI_DODICI = 11;
    private static final int DODICI_TREDICI = 12;
    private static final int TREDICI_QUATTORDICI = 13;
    private static final int QUATTORDICI_QUINDICI = 14;
    private static final int QUINDICI_SEDICI = 15;
    private static final int SEDICI_DICIASSETTE = 16;
    private static final int DICIASETTE_DICIOTTO = 17;
    private static final int DICIOTTO_DICIANOVE = 18;
    private static final int DICIANOVE_VENTI = 19;
    private static final int VENTI_VENTUNO = 20;
    private static final int VENTUNO_VENTIDUE = 21;
    private static final int VENTIDUE_VENTITRE = 22;
    private static final int VENTITRE_MEZZANOTTE = 23;

    private boolean[] fasceOrarie = new boolean[24];

    public FasciaOraria(LocalTime oraApertura, LocalTime oraChiusura) {
        int chiusura = oraChiusura.getHour() == 0 ? 24 : oraChiusura.getHour();
        for (int i = 0; i < fasceOrarie.length; i++) {
            fasceOrarie[i] = (i >= oraApertura.getHour() && i < chiusura);
        }
    }

    public boolean[] getFasceOrarie() { return fasceOrarie; }

    private void rimuoviDisponibilitaFasciaOraria(int fasciaOraria) {
        fasceOrarie[fasciaOraria] = false;
    }

    public void aggiornaFasciaOraria(int oraInizio, int oraFine) {
        int differenza = oraFine - oraInizio;
        if (differenza < 0) {
            // Gestione casi particolari (es. 23-00)
            if (oraInizio == 23 && oraFine == 0) {
                differenza = 1;
                oraInizio = 23;
            } else if (oraInizio == 0) {
                differenza = 24 - oraFine;
                oraInizio = oraFine;
            } else {
                return;
            }
        }
        for (int i = oraInizio; i < oraInizio + differenza && i < 24; i++) {
            rimuoviDisponibilitaFasciaOraria(i);
        }
    }

    private String stato(boolean libero) {
        return libero ? "Libero" : "Occupato";
    }

    @Override
    public String toString() {
        return "00-01 = " + stato(fasceOrarie[MEZZANOTTE_UNA]) + "\n" +
               "01-02 = " + stato(fasceOrarie[UNA_DUE]) + "\n" +
               "02-03 = " + stato(fasceOrarie[DUE_TRE]) + "\n" +
               "03-04 = " + stato(fasceOrarie[TRE_QUATTRO]) + "\n" +
               "04-05 = " + stato(fasceOrarie[QUATTRO_CINQUE]) + "\n" +
               "05-06 = " + stato(fasceOrarie[CINQUE_SEI]) + "\n" +
               "06-07 = " + stato(fasceOrarie[SEI_SETTE]) + "\n" +
               "07-08 = " + stato(fasceOrarie[SETTE_OTTO]) + "\n" +
               "08-09 = " + stato(fasceOrarie[OTTO_NOVE]) + "\n" +
               "09-10 = " + stato(fasceOrarie[NOVE_DIECI]) + "\n" +
               "10-11 = " + stato(fasceOrarie[DIECI_UNDICI]) + "\n" +
               "11-12 = " + stato(fasceOrarie[UNDICI_DODICI]) + "\n" +
               "12-13 = " + stato(fasceOrarie[DODICI_TREDICI]) + "\n" +
               "13-14 = " + stato(fasceOrarie[TREDICI_QUATTORDICI]) + "\n" +
               "14-15 = " + stato(fasceOrarie[QUATTORDICI_QUINDICI]) + "\n" +
               "15-16 = " + stato(fasceOrarie[QUINDICI_SEDICI]) + "\n" +
               "16-17 = " + stato(fasceOrarie[SEDICI_DICIASSETTE]) + "\n" +
               "17-18 = " + stato(fasceOrarie[DICIASETTE_DICIOTTO]) + "\n" +
               "18-19 = " + stato(fasceOrarie[DICIOTTO_DICIANOVE]) + "\n" +
               "19-20 = " + stato(fasceOrarie[DICIANOVE_VENTI]) + "\n" +
               "20-21 = " + stato(fasceOrarie[VENTI_VENTUNO]) + "\n" +
               "21-22 = " + stato(fasceOrarie[VENTUNO_VENTIDUE]) + "\n" +
               "22-23 = " + stato(fasceOrarie[VENTIDUE_VENTITRE]) + "\n" +
               "23-00 = " + stato(fasceOrarie[VENTITRE_MEZZANOTTE]) + "\n";
    }
}