package Model;

import java.util.GregorianCalendar;

public abstract class RegistrationHandler {
    public Utente istanziaUtente(String nome, String cognome, GregorianCalendar dataNascita) {
        return nuovoUtente(nome, cognome, dataNascita);
    }
    public abstract Utente nuovoUtente(String nome, String cognome, GregorianCalendar dataNascita);
}