package Model;


import Interface.IRegistrationStrategy;


import java.util.Calendar;
import java.util.GregorianCalendar;

public  class Utente {
    private int id;
    private String nome;
    private String cognome;
    private GregorianCalendar dataNascita;
    private String username;
    private String password;
    private IRegistrationStrategy registerStrategy;

    public Utente(){}

    public Utente(String nome, String cognome, GregorianCalendar dataNascita, IRegistrationStrategy registerStrategy) {
    
    	this.nome = nome;
        this.cognome = cognome;
        this.dataNascita = dataNascita;
        this.registerStrategy = registerStrategy;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public GregorianCalendar getDataNascita() {
        return dataNascita;
    }

    public void setDataNascita(GregorianCalendar dataNascita) {
        this.dataNascita = dataNascita;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

   

    public IRegistrationStrategy getRegisterStrategy() {
        return registerStrategy;
    }

    //metodo per gestire correttamente l'incremento dell'id del giocatore
 
 
    
    @Override
    public String toString() {
        return  "id='" + id + '\'' +
                ", nome='" + nome + '\'' +
                ", cognome='" + cognome + '\'' +
                ", dataNascita=" + dataNascita.get(Calendar.DAY_OF_MONTH) +
                "/" +  ( dataNascita.get(Calendar.MONTH) + 1) +
                "/" +  dataNascita.get(Calendar.YEAR) + '\'' +
                ", username='" + username + '\'' +
                ", password='" + password + '\'';
    }
}
