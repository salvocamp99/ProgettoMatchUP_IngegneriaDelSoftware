package Model;

import java.util.LinkedList;
import java.util.GregorianCalendar;
import java.util.List;

public class Campo {
    private int id;
    private String categoria;
    private String tipologia;
    private double tariffaOraria;
    //private List<Prenotazione> listaPrenotazioniCampo;
    
    public Campo() {

       // this.listaPrenotazioniCampo = new LinkedList<Prenotazione>();
    }

    public Campo(int id, String categoria, String tipologia, double tariffaOraria) {
        this.id = id;
        this.categoria = categoria;
        this.tipologia = tipologia;
        this.tariffaOraria = tariffaOraria;
     //   this.listaPrenotazioniCampo = new LinkedList<Prenotazione>();
    }

    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	
	public String getTipologia() {
		return tipologia;
	}

	public void setTipologia(String tipologia) {
		this.tipologia = tipologia;
	}

	public double getTariffaOraria() {
		return tariffaOraria;
	}
	public void setTariffaOraria(double tariffaOraria) {
		this.tariffaOraria = tariffaOraria;
	}


	@Override
	public String toString() {
		 return "Campo{" +
	                "id='" + id + '\'' +
	                ", categoria='" + categoria + '\'' +
	                ", tipologia='" + tipologia+ '\'' +
	                ", tariffaOraria='" + tariffaOraria+ '\'' +
	                '}';
	    }
	
	
}