package Model;

public class RegistrationHandlerFactory {
    private static RegistrationHandlerFactory factory;

    private RegistrationHandlerFactory() {}

    public static RegistrationHandlerFactory getInstance() {
        if (factory == null) factory = new RegistrationHandlerFactory();
        return factory;
    }

    public RegistrationHandler getGiocatoreHandler() {
        return new RegistrationGiocatoreHandler();
    }

    public RegistrationHandler getGestoreHandler() {
        return new RegistrationGestoreHandler();
    }


  
}