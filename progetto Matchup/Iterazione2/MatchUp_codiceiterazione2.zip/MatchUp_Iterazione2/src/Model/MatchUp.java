package Model;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Model.RegistrationHandler;
import Model.Utente;
import Eccezioni.AgeNotValidException;
import Eccezioni.NameNotValidException;
import Eccezioni.NumberNotValidException;

import java.time.LocalTime;
import java.util.*;


import Model.Struttura;

public class MatchUp {
    private static MatchUp instance;

    private HashMap<String, Struttura> mappaStrutture;
    private LinkedList<Prenotazione> catalogoPrenotazioni;
    private LinkedList<Utente> listaUtenti;
    private Prenotazione prenotazioneCorrente;
    private Utente utenteCorrente;
    private Struttura strutturaCorrente;

    private MatchUp() {
        mappaStrutture = new HashMap<>();
        catalogoPrenotazioni = new LinkedList<>();
        listaUtenti = new LinkedList<>();
    }

    public static MatchUp getInstance() {
        if (instance == null) instance = new MatchUp();
        return instance;
    }

    // ---------- Getter ----------
    public Struttura getStrutturaCorrente() { return strutturaCorrente; }
    public LinkedList<Utente> getListaUtenti() { return listaUtenti; }
    public HashMap<String, Struttura> getMappaStrutture() { return mappaStrutture; }
    public LinkedList<Prenotazione> getCatalogoPrenotazioni() { return catalogoPrenotazioni; }
    public Prenotazione getPrenotazioneCorrente() { return prenotazioneCorrente; }
    public Utente getUtenteCorrente() { return utenteCorrente; }

    // ---------- UC2: Registrazione Giocatore ----------
    // Contratto 2.6.1
    public void istanziaNuovoUtente(String nome, String cognome, GregorianCalendar dataNascita, RegistrationHandler factoryMethod) throws AgeNotValidException{

        Utente user = factoryMethod.istanziaUtente(nome, cognome, dataNascita);
       
        if(user.getRegisterStrategy().controllaEta(dataNascita)){
            this.utenteCorrente = user;
            mostraRiepilogoUtente(user);
        }else{
            throw new AgeNotValidException(user);
        }

    }
    public void verificaValiditaNomeCognome(String nome, String cognome) throws NameNotValidException {
        Pattern pattern = Pattern.compile("^[a-zA-ZàèéìòùÀÈÉÌÒÙ' ]{2,}$");
        if (!pattern.matcher(nome).matches() || !pattern.matcher(cognome).matches()) {
            throw new NameNotValidException();
        }
    }
    // Contratto 2.6.2
    public boolean inserisciCredenziali(String username, String password) {
        if (utenteCorrente == null) return false;
        if (!controllaValiditaCredenziali(username,password)) return false;
        utenteCorrente.setUsername(username);
        utenteCorrente.setPassword(password);
        return true;
    }

    // Contratto 2.6.3
    public boolean confermaRegistrazioneUtente(){
    	if(utenteCorrente == null){
            return false;
        }

        if(utenteCorrente instanceof Giocatore){
            utenteCorrente.setId(Giocatore.getProssimoId());
        }else if(utenteCorrente instanceof Gestore){
            utenteCorrente.setId(Gestore.getProssimoId());
        }

        boolean esito;
        esito = listaUtenti.add(this.utenteCorrente);
        if(utenteCorrente instanceof Giocatore){
            this.utenteCorrente = null;
        }
        return esito;

    }

    

 
    // Contratto 2.5.4
    public void inserisciDatiStruttura(String nome, String localita, String numeroTelefono,
    LocalTime orarioApertura, LocalTime orarioChiusura) {
        if (!(utenteCorrente instanceof Gestore)) return;
        String codice = "A" + (mappaStrutture.size() + 1);
        Struttura s = new Struttura(codice, nome, localita, numeroTelefono, orarioApertura, orarioChiusura);
        this.strutturaCorrente = s;
    }
    
    

    // Contratto 2.5.5
    public void inserisciCampoStruttura(String categoriaCampo, String tipologia, double tariffaOraria) {
        if (strutturaCorrente == null) return;
        //String tipoCompleto = categoriaCampo + " - " + tipologia;
        strutturaCorrente.inserisciCampo(categoriaCampo,tipologia, tariffaOraria);
    }
    

    // Contratto 2.5.6
    public boolean confermaRegistrazioneStruttura() {
        if (strutturaCorrente == null || utenteCorrente == null || !(utenteCorrente instanceof Gestore)) {
            return false;
        }
        mappaStrutture.put(strutturaCorrente.getCodice(), strutturaCorrente);
        ((Gestore) utenteCorrente).setStruttura(strutturaCorrente);
        this.strutturaCorrente = null;
        this.utenteCorrente = null;  // logout automatico
        return true;
    }
    
    public Struttura getStruttura(String codiceStruttura){

        return mappaStrutture.get(codiceStruttura);
     }
    
    public void aggiungiStruttura(Struttura s1) {
    	mappaStrutture.put(s1.getCodice(),s1);
    }

    
    

    // ---------- UC3 Perfezionato ----------
    // Contratto 2.7.1
    public boolean login(String username, String password) {
        if (this.utenteCorrente != null) return false;
        for (Utente u : listaUtenti) {
            if (u.getUsername() != null && u.getUsername().equals(username) &&
                u.getPassword() != null && u.getPassword().equals(password)) {
                this.utenteCorrente = u;
                return true;
            }
        }
        return false;
    }

    // Metodi per la ricerca e visualizzazione (usati in UC3)
    public LinkedList<Struttura> effettuaRicercaStruttura(String categoriaCampo) {
        LinkedList<Struttura> listaStrutture = new LinkedList<>();
        for (Struttura s : mappaStrutture.values()) {
            if (s.verificaCategoria(categoriaCampo)) listaStrutture.add(s);
        }
        return listaStrutture;
    }

    public LinkedList<Campo> mostraCampiStruttura(String codiceStruttura) {
        Struttura s = mappaStrutture.get(codiceStruttura);
        return s == null ? new LinkedList<>() : s.getListaCampiStruttura();
    }

    // Contratto 2.7.2
    public FasciaOraria richiediDisponibilita(String codiceStruttura, int idCampo,
                                              GregorianCalendar dataDesiderata) {
        Struttura s = mappaStrutture.get(codiceStruttura);
        if (s == null) return null;
        return mostraFasceOrarie(codiceStruttura, idCampo, dataDesiderata,
                              s.getOrarioApertura(), s.getOrarioChiusura());
    }

    private FasciaOraria mostraFasceOrarie(String codiceStruttura, int idCampo,
                                        GregorianCalendar dataDesiderata, LocalTime orarioApertura, LocalTime orarioChiusura) {
    	LinkedList<Prenotazione> PrenotazioniPerData = new LinkedList<>();
        FasciaOraria fo = new FasciaOraria(orarioApertura, orarioChiusura);
        for (Prenotazione p : catalogoPrenotazioni) {
            if (p.getStruttura().getCodice().equals(codiceStruttura) &&
                p.getCampo().getId() == idCampo &&
                stessoGiorno(p.getDataInizio(), dataDesiderata)) {
            	  PrenotazioniPerData.add(p);
            	  fo.aggiornaFasciaOraria(p.getDataInizio().get(Calendar.HOUR_OF_DAY),p.getDataFine().get(Calendar.HOUR_OF_DAY));
            }
        }
        return fo;
    }

    
    private boolean stessoGiorno(GregorianCalendar d1, GregorianCalendar d2) {
        return d1.get(Calendar.YEAR) == d2.get(Calendar.YEAR) &&
               d1.get(Calendar.MONTH) == d2.get(Calendar.MONTH) &&
               d1.get(Calendar.DAY_OF_MONTH) == d2.get(Calendar.DAY_OF_MONTH);
    }

    public boolean prenotaCampo(String codiceStruttura, int idCampo,
                                GregorianCalendar dataInizio, GregorianCalendar dataFine) {
        if (!(utenteCorrente instanceof Giocatore)) return false;

        Struttura s = mappaStrutture.get(codiceStruttura);
        if (s == null || s.getCampo(idCampo) == null) return false;

        if (!s.controllaDisponibilitaStruttura(dataInizio, dataFine)) return false;
        if (!controllaDisponibilitaCampo(codiceStruttura, idCampo, dataInizio, dataFine)) return false;

        Prenotazione p = new Prenotazione(
            catalogoPrenotazioni.size() + 1,
            dataInizio, dataFine,
            (Giocatore) utenteCorrente,
            s, s.getCampo(idCampo)
        );
        this.prenotazioneCorrente = p;
        mostraRiepilogoDati(p);
        return true;
    }

    private boolean controllaDisponibilitaCampo(String codiceStruttura, int idCampo,
                                               GregorianCalendar inizio, GregorianCalendar fine) {
        for (Prenotazione p : catalogoPrenotazioni) {
            if (p.getStruttura().getCodice().equals(codiceStruttura) &&
                p.getCampo().getId() == idCampo) {
                GregorianCalendar pInizio = p.getDataInizio();
                GregorianCalendar pFine = p.getDataFine();
                if (pInizio.get(Calendar.YEAR) == inizio.get(Calendar.YEAR) &&
                        pInizio.get(Calendar.MONTH) == inizio.get(Calendar.MONTH) &&
                        pInizio.get(Calendar.DAY_OF_MONTH) == inizio.get(Calendar.DAY_OF_MONTH)) {
                        if (inizio.before(pFine) && fine.after(pInizio)) {
                            return false; // sovrapposizione nello stesso giorno
                        }
                    }
                }
            }
        return true;
    }

    public boolean confermaPrenotazione() {
        if (!(utenteCorrente instanceof Giocatore) || prenotazioneCorrente == null) {
            return false;
        }
        catalogoPrenotazioni.add(prenotazioneCorrente);
        ((Giocatore) utenteCorrente).incrementaNumeroPrenotazioniEffettuate();
        prenotazioneCorrente = null;
        return true;
    }

    // ---------- Metodi di utilità ----------
    private void mostraRiepilogoDati(Prenotazione p) {
        System.out.println("Prenotazione numero: " + p.getId() +
                           " presso struttura: " + p.getStruttura().getNome());
        System.out.println("Id campo: " + p.getCampo().getId());
        System.out.println("Data inizio: " + p.getDataInizio().getTime());
        System.out.println("Data fine: " + p.getDataFine().getTime());
        System.out.println("Importo: " + p.getCostoTotale());
    }

    private void mostraRiepilogoUtente(Utente u) {
       // System.out.println("Id: " + u.getId());
        System.out.println("Nome: " + u.getNome() + " Cognome: " + u.getCognome());
        System.out.println("Data di nascita: " + u.getDataNascita().get(Calendar.DAY_OF_MONTH) +
                           "/" + (u.getDataNascita().get(Calendar.MONTH) + 1) +
                           "/" + u.getDataNascita().get(Calendar.YEAR));
    }


    
    private boolean controllaValiditaCredenziali(String username, String password) {
        for (Utente u : listaUtenti) {
            if (u.getUsername() != null && u.getUsername().equals(username)) return false;
        }
        // 2. Controllo password: almeno 8 caratteri
        if (password == null || password.length() < 8) {
            return false;
        }
        
     // 3. Controllo password: almeno un carattere speciale
        Pattern specialCharPattern = Pattern.compile("[!@#$%^&*()_+\\-=\\[\\]{}|;:,.<>?/]");
        Matcher matcher = specialCharPattern.matcher(password);
        if (!matcher.find()) {
            return false; // nessun carattere speciale trovato
        }

        return true; // tutte le verifiche sono passate
    }
        

    public void verificaValiditaTelefono(String numeroTelefono) throws NumberNotValidException {
        Pattern pattern = Pattern.compile("^\\d{10}$");
        Matcher m = pattern.matcher(numeroTelefono);
        if (!m.matches()) throw new NumberNotValidException();
    }

    public Utente ricercaUtente(String username){

        for(int i = 0; i<listaUtenti.size();i++){

            Utente u = listaUtenti.get(i);
            if(u.getUsername().equals(username)){

                return u;
            }

        }
        return null;
    }

    public void logout() {
        this.utenteCorrente = null;
    }

    public LinkedList<Prenotazione> visualizzaPrenotazioni() {
        LinkedList<Prenotazione> risultato = new LinkedList<>();
        Utente utente = getUtenteCorrente();

        // Se è un Gestore: restituisce le prenotazioni effettuate nella sua Struttura
        if (utente instanceof Gestore) {
            Gestore gestore = (Gestore) utente;
            for (Prenotazione p : catalogoPrenotazioni) {
                if (p.getStruttura() != null && p.getStruttura().equals(gestore.getStruttura())) {
                    risultato.add(p);
                }
            }
        } 
        // Se è un Giocatore: restituisce solo le prenotazioni effettuate da lui
        else if (utente instanceof Giocatore) {
            Giocatore giocatore = (Giocatore) utente;
            for (Prenotazione p : catalogoPrenotazioni) {
                if (p.getGiocatore() != null && p.getGiocatore().equals(giocatore)) {
                    risultato.add(p);
                }
            }
        }

        return risultato;
    }
}