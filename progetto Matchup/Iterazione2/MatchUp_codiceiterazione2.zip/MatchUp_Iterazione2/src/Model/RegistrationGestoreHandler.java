package Model;

import java.util.GregorianCalendar;

public class RegistrationGestoreHandler extends RegistrationHandler {
    @Override
    public Utente nuovoUtente(String nome, String cognome, GregorianCalendar dataNascita) {
        return new Gestore(nome, cognome, dataNascita);
    }
}