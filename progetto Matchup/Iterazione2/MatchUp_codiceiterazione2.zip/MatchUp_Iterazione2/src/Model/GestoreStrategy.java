package Model;

import Interface.IRegistrationStrategy;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class GestoreStrategy implements IRegistrationStrategy{

	@Override
	public boolean controllaEta(GregorianCalendar dataNascita) {
		  
		        Calendar current = GregorianCalendar.getInstance();
		        int age = current.get(Calendar.YEAR) - dataNascita.get(Calendar.YEAR);
		        if (dataNascita.get(Calendar.MONTH) > current.get(Calendar.MONTH) ||
		            (dataNascita.get(Calendar.MONTH) == current.get(Calendar.MONTH) &&
		             dataNascita.get(Calendar.DAY_OF_MONTH) > current.get(Calendar.DAY_OF_MONTH))) {
	
		   age--; 
		   }
		   return age >= 18;
	}
	
	
}