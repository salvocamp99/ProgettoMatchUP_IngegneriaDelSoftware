package Model;

import Interface.IPricingStrategy;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Prenotazione {
    private int id;
    private double costoTotale;
    private GregorianCalendar dataInizio;
    private GregorianCalendar dataFine;
    private Giocatore giocatore;
    private Struttura struttura;
    private Campo campo;

    public Prenotazione() {}

    public Prenotazione(int id, GregorianCalendar dataInizio, GregorianCalendar dataFine,
                        Giocatore giocatore, Struttura struttura, Campo campo) {
        this.id = id;
        this.dataInizio = dataInizio;
        this.dataFine = dataFine;
        this.giocatore = giocatore;
        this.struttura = struttura;
        this.campo = campo;
        this.costoTotale = calcolaCostoTotale(dataInizio, dataFine);
    }

    // Getter e Setter
    
    public int getId() { return id; }
    
    public void setId(int id) {
		this.id = id;
	}
    

    public double getCostoTotale() {
		return costoTotale;
	}

	public void setCostoTotale(double costoTotale) {
		this.costoTotale = costoTotale;
	}

	public Giocatore getGiocatore() {
		return giocatore;
	}

	public void setGiocatore(Giocatore giocatore) {
		this.giocatore = giocatore;
	}

    public GregorianCalendar getDataInizio() { return dataInizio; }
    public void setDataInizio(GregorianCalendar dataInizio) { this.dataInizio = dataInizio; }
    public GregorianCalendar getDataFine() { return dataFine; }
    public void setDataFine(GregorianCalendar dataFine) { this.dataFine = dataFine; }
    public Struttura getStruttura() { return struttura; }
    public void setStruttura(Struttura struttura) { this.struttura = struttura; }
    public Campo getCampo() { return campo; }
    public void setCampo(Campo campo) { this.campo = campo; }

    private int convertiOraChiusura(int oraChiusura) {
        return oraChiusura == 0 ? 24 : oraChiusura;
    }

    private double calcolaCostoTotale(GregorianCalendar dataInizio, GregorianCalendar dataFine) {
        int ore = convertiOraChiusura(dataFine.get(Calendar.HOUR_OF_DAY)) -
                  dataInizio.get(Calendar.HOUR_OF_DAY);
        double costoTotale = ore * campo.getTariffaOraria();

        PricingStrategyFactory factory = PricingStrategyFactory.getInstance();
        IPricingStrategy strategy = factory.getPricingStrategy();
        return strategy.applicaSconto(costoTotale, dataInizio, dataFine,
                                      giocatore.getNumeroPrenotazioniEffettuate());
    }

    @Override
    public String toString() {
        return "Prenotazione{" + "id=" + id + ", costoTotale=" + costoTotale +
               ", dataInizio=" + dataInizio.getTime() + ", dataFine=" + dataFine.getTime() +
               ", giocatore=" + giocatore + ", struttura=" + struttura.getCodice() +
               ", campo=" + campo.getTipologia() + '}';
    }
}